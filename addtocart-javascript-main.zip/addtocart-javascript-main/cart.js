<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    function addToCart(product) {
        const user = JSON.parse(localStorage.getItem("user"));

        if (!user) {
            // अगर यूजर लॉगइन नहीं है तो अलर्ट दिखाओ
            Swal.fire({
                icon: 'warning',
                title: 'Login Required',
                text: 'Please login to add items to the cart!',
                confirmButtonText: 'OK'
            });
            return; // आगे का कोड रन नहीं होगा
        }

        // अगर यूजर लॉगिन है, तो प्रोडक्ट ऐड होगा
        let cart = JSON.parse(localStorage.getItem("cart")) || [];
        cart.push(product);
        localStorage.setItem("cart", JSON.stringify(cart));

        Swal.fire({
            icon: 'success',
            title: 'Added to Cart',
            text: `${product.name} has been added to your cart.`,
            confirmButtonText: 'OK'
        });
    }

    // अगर कोई बिना लॉगिन के cart.html खोलने की कोशिश करे, तो उसे रोक दो
    document.addEventListener("DOMContentLoaded", function () {
        const user = JSON.parse(localStorage.getItem("user"));
        if (!user && window.location.pathname.includes("cart.html")) {
            Swal.fire({
                icon: 'error',
                title: 'Access Denied',
                text: 'You need to login first!',
                confirmButtonText: 'OK'
            }).then(() => {
                window.location.href = "login.html"; // यूजर को लॉगिन पेज पर भेज दो
            });
        }
    });
</script>
